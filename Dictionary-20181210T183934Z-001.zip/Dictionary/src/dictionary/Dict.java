/***

            Bismillahir Rahmanir Rahim
            Read in the name of Allah, who created you!!!
            Author : Shah Newaj Rabbi Shishir,
            Department of CSE, City University, Bangladesh.

***/

package dictionary;

import java.util.HashMap;

public class Dict extends javax.swing.JFrame {
    String str,ans,appname="Bangla Translator",version="Version : 1.0",developed="Developed by,",developer="Shah Newaj Rabbi Shishir",institute="City University, Bangladesh",
    contact="Developer e-mail",email="shahshishir.09@gmail.com";
    static public HashMap <String,String> map = new HashMap<>(); 
    
    public Dict() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        WordBook = new javax.swing.JPanel();
        Logo = new javax.swing.JLabel();
        WriteEngLabel = new javax.swing.JLabel();
        EngField = new javax.swing.JTextField();
        ResultEngLabel = new javax.swing.JLabel();
        EngtoBanResult = new javax.swing.JTextField();
        EngtoBanButton = new javax.swing.JButton();
        WriteBanLabel = new javax.swing.JLabel();
        BanField = new javax.swing.JTextField();
        BantoEngButton = new javax.swing.JButton();
        ResultBanLabel = new javax.swing.JLabel();
        BantoEngResult = new javax.swing.JTextField();
        ClearEngButton = new javax.swing.JButton();
        ClearBanButton = new javax.swing.JButton();
        AboutButton = new javax.swing.JButton();
        Info = new javax.swing.JLabel();
        Appname = new javax.swing.JLabel();
        Version = new javax.swing.JLabel();
        Developed = new javax.swing.JLabel();
        Developer = new javax.swing.JLabel();
        Institute = new javax.swing.JLabel();
        Contact = new javax.swing.JLabel();
        Email = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        WordBook.setBackground(new java.awt.Color(0, 51, 51));
        WordBook.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Logo.setIcon(new javax.swing.ImageIcon("G:\\Edit.png")); // NOI18N
        WordBook.add(Logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        WriteEngLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        WriteEngLabel.setForeground(new java.awt.Color(0, 255, 255));
        WriteEngLabel.setText("Write any word, idiom, proverb or sentence in English ");
        WordBook.add(WriteEngLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 30, -1, -1));

        EngField.setBackground(new java.awt.Color(51, 0, 51));
        EngField.setFont(new java.awt.Font("Cambria Math", 1, 20)); // NOI18N
        EngField.setForeground(new java.awt.Color(153, 153, 0));
        EngField.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        EngField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EngFieldActionPerformed(evt);
            }
        });
        WordBook.add(EngField, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 540, 30));

        ResultEngLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        ResultEngLabel.setForeground(new java.awt.Color(0, 255, 255));
        ResultEngLabel.setText("Result in Bengali");
        WordBook.add(ResultEngLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 130, -1, -1));

        EngtoBanResult.setBackground(new java.awt.Color(51, 0, 51));
        EngtoBanResult.setFont(new java.awt.Font("Siyam Rupali", 1, 16)); // NOI18N
        EngtoBanResult.setForeground(new java.awt.Color(153, 153, 0));
        EngtoBanResult.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        EngtoBanResult.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EngtoBanResultActionPerformed(evt);
            }
        });
        WordBook.add(EngtoBanResult, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, 540, 30));

        EngtoBanButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        EngtoBanButton.setForeground(new java.awt.Color(0, 102, 102));
        EngtoBanButton.setText("Check translation");
        EngtoBanButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EngtoBanButtonActionPerformed(evt);
            }
        });
        WordBook.add(EngtoBanButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 90, -1, 30));

        WriteBanLabel.setFont(new java.awt.Font("Siyam Rupali", 1, 14)); // NOI18N
        WriteBanLabel.setForeground(new java.awt.Color(0, 255, 255));
        WriteBanLabel.setText("বাংলায় কিছু লিখুন");
        WordBook.add(WriteBanLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 250, -1, -1));

        BanField.setBackground(new java.awt.Color(51, 0, 51));
        BanField.setFont(new java.awt.Font("Siyam Rupali", 1, 16)); // NOI18N
        BanField.setForeground(new java.awt.Color(153, 153, 0));
        BanField.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        BanField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BanFieldActionPerformed(evt);
            }
        });
        WordBook.add(BanField, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 280, 530, 30));

        BantoEngButton.setFont(new java.awt.Font("Siyam Rupali", 1, 14)); // NOI18N
        BantoEngButton.setForeground(new java.awt.Color(0, 102, 102));
        BantoEngButton.setText("ইংরেজিতে অনুবাদ করুন");
        BantoEngButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BantoEngButtonActionPerformed(evt);
            }
        });
        WordBook.add(BantoEngButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 320, -1, 30));

        ResultBanLabel.setFont(new java.awt.Font("Siyam Rupali", 1, 14)); // NOI18N
        ResultBanLabel.setForeground(new java.awt.Color(0, 255, 255));
        ResultBanLabel.setText("ইংরেজিতে ফলাফল");
        WordBook.add(ResultBanLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 360, -1, -1));

        BantoEngResult.setEditable(false);
        BantoEngResult.setBackground(new java.awt.Color(51, 0, 51));
        BantoEngResult.setFont(new java.awt.Font("Cambria Math", 1, 20)); // NOI18N
        BantoEngResult.setForeground(new java.awt.Color(153, 153, 0));
        BantoEngResult.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        WordBook.add(BantoEngResult, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 390, 520, 30));

        ClearEngButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        ClearEngButton.setForeground(new java.awt.Color(0, 102, 102));
        ClearEngButton.setText("Clear it!");
        ClearEngButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearEngButtonActionPerformed(evt);
            }
        });
        WordBook.add(ClearEngButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 190, -1, -1));

        ClearBanButton.setFont(new java.awt.Font("Siyam Rupali", 1, 14)); // NOI18N
        ClearBanButton.setForeground(new java.awt.Color(0, 102, 102));
        ClearBanButton.setText("মুছে দিন!");
        ClearBanButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearBanButtonActionPerformed(evt);
            }
        });
        WordBook.add(ClearBanButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 430, -1, -1));

        AboutButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        AboutButton.setForeground(new java.awt.Color(153, 153, 0));
        AboutButton.setText("About");
        AboutButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AboutButtonActionPerformed(evt);
            }
        });
        WordBook.add(AboutButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 90, -1, -1));
        WordBook.add(Info, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 50, -1, -1));

        Appname.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Appname.setForeground(new java.awt.Color(102, 102, 0));
        WordBook.add(Appname, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 120, -1, -1));

        Version.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Version.setForeground(new java.awt.Color(102, 102, 0));
        WordBook.add(Version, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 130, -1, -1));

        Developed.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Developed.setForeground(new java.awt.Color(102, 102, 0));
        WordBook.add(Developed, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 160, -1, -1));

        Developer.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Developer.setForeground(new java.awt.Color(102, 102, 0));
        WordBook.add(Developer, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 170, -1, -1));

        Institute.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Institute.setForeground(new java.awt.Color(102, 102, 0));
        WordBook.add(Institute, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 180, -1, -1));

        Contact.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Contact.setForeground(new java.awt.Color(102, 102, 0));
        WordBook.add(Contact, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 210, -1, -1));

        Email.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Email.setForeground(new java.awt.Color(102, 102, 0));
        WordBook.add(Email, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 220, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WordBook, javax.swing.GroupLayout.PREFERRED_SIZE, 769, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WordBook, javax.swing.GroupLayout.PREFERRED_SIZE, 530, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BantoEngButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BantoEngButtonActionPerformed
        str = BanField.getText();
        ans = map.get(str);
        BantoEngResult.setText(ans);
    }//GEN-LAST:event_BantoEngButtonActionPerformed

    private void BanFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BanFieldActionPerformed
        
    }//GEN-LAST:event_BanFieldActionPerformed

    private void EngtoBanButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EngtoBanButtonActionPerformed
        str = EngField.getText();
        str = str.substring(0, 1).toUpperCase()+ str.substring(1, str.length()).toLowerCase();
        ans = map.get(str);
        EngtoBanResult.setText(ans);
    }//GEN-LAST:event_EngtoBanButtonActionPerformed

    private void EngtoBanResultActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EngtoBanResultActionPerformed
        
    }//GEN-LAST:event_EngtoBanResultActionPerformed

    private void AboutButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AboutButtonActionPerformed
        Appname.setText(appname);
        Version.setText(version);
        Developed.setText(developed);
        Developer.setText(developer);
        Institute.setText(institute);
        Contact.setText(contact);
        Email.setText(email);
    }//GEN-LAST:event_AboutButtonActionPerformed

    private void ClearEngButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearEngButtonActionPerformed
        EngField.setText("");
        EngtoBanResult.setText("");
    }//GEN-LAST:event_ClearEngButtonActionPerformed

    private void ClearBanButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearBanButtonActionPerformed
        BanField.setText("");
        BantoEngResult.setText("");
    }//GEN-LAST:event_ClearBanButtonActionPerformed

    private void EngFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EngFieldActionPerformed

    }//GEN-LAST:event_EngFieldActionPerformed

    public static void main(String args[]) {
        map.put("A","একটি");
        map.put("Abacus","গণনা করার যন্তর");
        map.put("Ant","পিঁপড়ে, পতঙ্গবিশেষ"); 
        map.put("Apple","আপেল, ফলবিশেষ");
        map.put("Bat","খেলার ব্যাট, বাদুড়");
        map.put("Ball","খেলার বল");
        map.put("Cat","বিড়াল, জন্তুবিশেষ");
        map.put("Crow","কাক, পক্ষীবিশেষ");
        map.put("Day","দিন");
        map.put("Dog","কুকুর, জন্তুবিশেষ");
        map.put("Egg","ডিম");
        map.put("Ear","কান");
        map.put("Fog","কুয়াশা");
        map.put("Frog","ব্যাঙ");
        map.put("Go","যাওয়া");
        map.put("Goat","ছাগল, জন্তুবিশেষ");
        map.put("Goal","উদ্দেশ্য, লক্ষ্যবস্তু");
        map.put("Horse", "ঘোড়া, জন্তুবিশেষ");
        map.put("House","বাড়ি, ঘর");
        map.put("Ink","লিখার কালি");
        map.put("In","ভিতরে");
        map.put("Jar","বয়াম, ভাণ্ড");
        map.put("Juice","রস, জুস");
        map.put("Kite","ঘুড়ি");
        map.put("Lemon","লেবু, ফলবিশেষ");
        map.put("Man","মানুষ ");
        map.put("Mother","মা");
        map.put("Father","বাবা");
        map.put("Sister","বোন");
        map.put("Brother","ভাই");
        map.put("Nut","বাদাম");
        map.put("Oil","তৈল");
        map.put("Pin","পেরেক");
        map.put("Quite","পুরোপুরি");
        map.put("Quit","মুক্ত, বরখাস্তকরণ, ছাড়িয়া যাওয়া");
        map.put("Ram","মেষরাশি, র‍্যাম");
        map.put("Sun","সূর্য");
        map.put("Truck","মোটরলরি");
        map.put("Owl","পেঁচা");
        map.put("University","বিশ্ববিদ্যালয়");
        map.put("Vast","সুবিশাল");
        map.put("Win","জয়, জয়লাভ করা");
        map.put("X-ray","রঞ্জন-রশ্মি");
        map.put("Yield","উৎপাদ, সমর্পণ করা");
        map.put("Zoo","চিড়িয়াখানা");
        map.put("Dictionary","অভিধান, শব্দকোষ");
        map.put("Computer","কম্পিউটার, গণনার যন্তর");
        map.put("Programming","প্রোগ্রামিং");
        map.put("Calculator","হিসাবকারী, গণনার যন্তর");
        map.put("Moon","চাঁদ, শশী");
        map.put("Subject","অধীন, দায়ী, অধীন লোক, বিষয়, বশে আনা");
        map.put("Semester","সেমিস্টার");
        map.put("Disc","ডিস্ক");
        map.put("The name of my Country is Bangladesh.","আমার দেশের নাম বাংলাদেশ");
        map.put("আমার দেশের নাম বাংলাদেশ","The name of my Country is Bangladesh.");
        map.put("Come here.","এদিকে আসুন");
        map.put("এদিকে আসুন","Come here.");
        map.put("Sit down.","বসুন");
        map.put("বসুন","Sit down.");
        map.put("Keep calm.","শান্ত হউন");
        map.put("শান্ত হউন","Keep calm.");
        map.put("I love you.","আমি তোমাকে ভালোবাসি");
        map.put("আমি তোমাকে ভালোবাসি","I love you.");
        map.put("The patient had died before the doctor came.","ডাক্তার আসিবার পূর্বে রোগী মারা গেলো");
        map.put("ডাক্তার আসিবার পূর্বে রোগী মারা গেলো","The patient had died before the doctor came.");
        map.put("May Allah bless you.","আল্লাহ তোমার মঙ্গল করুন");
        map.put("আল্লাহ তোমার মঙ্গল করুন","May Allah bless you.");
        map.put("Walking is a good exercise.","হাঁটা ভালো ব্যায়াম");
        map.put("হাঁটা ভালো ব্যায়াম","Walking is a good exercise.");
        map.put("English is an international language.","ইংরেজি একটি আন্তর্জাতিক ভাষা");
        map.put("ইংরেজি একটি আন্তর্জাতিক ভাষা","English is an international language.");
        map.put("We do not do bad things.","আমাদের খারাপ কাজ করি না");
        map.put("আমাদের খারাপ কাজ করি না","We do not do bad things.");
        map.put("Do you have your assignment ready?","তোমার এসাইনমেন্ট প্রস্তুত কি?");
        map.put("তোমার এসাইনমেন্ট প্রস্তুত কি?","Do you have your assignment ready?");
        map.put("Should I go there?","আমার সেখানে যাওয়া উচিৎ কি?");
        map.put("আমার সেখানে যাওয়া উচিৎ কি?","Should I go there?");
        map.put("Take care of you.","নিজের খেয়াল রেখো");
        map.put("নিজের খেয়াল রেখো","Take care of you.");
        map.put("Give me the pen.","আমাকে কলমটি দাও");
        map.put("আমাকে কলমটি দাও","Give me the pen.");
        map.put("Do it now.","এটি এখনই করো");
        map.put("এটি এখনই করো","Do it now.");
        map.put("Be honest.","সৎ হও");
        map.put("সৎ হও","Be honest.");
        map.put("Never tell a lie.","কখনো মিথ্যা বলো না");
        map.put("কখনো মিথ্যা বলো না","Never tell a lie.");
        map.put("What a talented girl she is!","সে কত মেধাবী মেয়ে!");
        map.put("সে কত মেধাবী মেয়ে!","What a talented girl she is!");
        map.put("Do not laugh at other's helplessness.","অন্যার অসহায়ত্ব দেখে হেসো না");
        map.put("অন্যার অসহায়ত্ব দেখে হেসো না","Do not laugh at other's helplessness.");
        map.put("Let him go there.","তাকে সেখানে যেতে দাও");
        map.put("তাকে সেখানে যেতে দাও","Let him go there.");
        map.put("May you live long.","দীর্ঘজীবি হও");
        map.put("দীর্ঘজীবি হও","May you live long.");
        map.put("Wish you all the best.","তোমার ভালো হোক");
        map.put("তোমার ভালো হোক","Wish you all the best.");
        map.put("Long live Bangladesh.","বাংলাদেশ দীর্ঘজীবি হোক");
        map.put("বাংলাদেশ দীর্ঘজীবি হোক","Long live Bangladesh.");
        map.put("How sweetly the cuckoo sings!","কোকিল কত সুমধুর গায়!");
        map.put("কোকিল কত সুমধুর গায়!","How sweetly the cuckoo sings!");
        map.put("What a pity!","কি দুঃখ!");
        map.put("কি দুঃখ!","What a pity!");
        map.put("What a wonderful land Bangladesh is!","বাংলাদেশ কত অপরূপ দেশ!");
        map.put("বাংলাদেশ কত অপরূপ দেশ!","What a wonderful land Bangladesh is!");
        map.put("Fantastic!","চমৎকার!");
        map.put("চমৎকার!","Fantastic!");
        map.put("What an idea!","কি একটি বুদ্ধি!");
        map.put("কি একটি বুদ্ধি!","What an idea!");
        map.put("Walk softly, please.","দয়া করে আস্তে হাঁটুন");
        map.put("দয়া করে আস্তে হাঁটুন","Walk softly, please.");
        map.put("Bravo! You have done a great job.","সাবাশ, দারুণ কাজ করেছো");
        map.put("সাবাশ, দারুণ কাজ করেছো","Bravo! You have done a great job.");
        map.put("পিঁপড়ে", "Ant"); 
        map.put("গণনা করার যন্তর","Abacus");
        map.put("একটি","A");
        map.put("আপেল","Apple");
        map.put("বাদুড়","Bat");
        map.put("খেলার বল","Ball");
        map.put("বিড়াল","Cat");
        map.put("কাক","Crow");
        map.put("দিন","Day");
        map.put("কুকুর","Dog");
        map.put("ডিম","Egg");
        map.put("কান","Ear");
        map.put("কুয়াশা","Fog");
        map.put("ব্যাঙ","Frog");
        map.put("যাওয়া","Go");
        map.put("ছাগল","Goat");
        map.put("উদ্দেশ্য","Goal");
        map.put("ঘোড়া","Horse");
        map.put("বাড়ি","House");
        map.put("লিখার কালি","Ink");
        map.put("ভিতরে","In");
        map.put("বয়াম","Jar");
        map.put("রস","Juice");
        map.put("ঘুড়ি","Kite");
        map.put("লেবু","Lemon");
        map.put("মানুষ ","Man");
        map.put("মা","Mother");
        map.put("বাবা","Father");
        map.put("বোন","Sister");
        map.put("ভাই","Brother");
        map.put("বাদাম","Nut");
        map.put("তৈল","Oil");
        map.put("পেরেক","Pin");
        map.put("পুরোপুরি","Quite");
        map.put("ছাড়িয়া যাওয়া","Quit");
        map.put("মেষরাশি","Ram");
        map.put("সূর্য","Sun");
        map.put("মোটরলরি","Truck");
        map.put("পেঁচা","Owl");
        map.put("বিশ্ববিদ্যালয়","University");
        map.put("সুবিশাল","Vast");
        map.put("জয়লাভ করা","Win");
        map.put("রঞ্জন-রশ্মি","X-ray");
        map.put("সমর্পণ করা","Yield");
        map.put("চিড়িয়াখানা","Zoo");
        map.put("অভিধান","Dictionary");
        map.put("কম্পিউটার","Computer");
        map.put("Programming","প্রোগ্রামিং");
        map.put("হিসাবকারী","Calculator");
        map.put("চাঁদ","Moon");
        map.put("অধীন","Subject");
        map.put("সেমিস্টার","Semester");
        map.put("ডিস্ক","Disc");
        map.put("নাচতে না জানলে উঠোন বাঁকা।","A bad workman quarrels with his tools.");
        map.put("A bad workman quarrels with his tools.","নাচতে না জানলে উঠোন বাঁকা।");
        map.put("যত গর্জে তত বর্ষে না।","A barking dog seldom bites.");
        map.put("A barking dog seldom bites.","যত গর্জে তত বর্ষে না।");
        map.put("মাথা নেই তার মাথাব্যথা।","A beggar cannot be a bankrupt.");
        map.put("A beggar cannot be a bankrupt.","মাথা নেই তার মাথাব্যথা।");
        map.put("নেংটার নেই বাটপাড়ের ভয়।","A beggar may sing before a pick-pocket.");
        map.put("A beggar may sing before a pick-pocket.","নেংটার নেই বাটপাড়ের ভয়।");
        map.put("বিনা মেঘে বজ্রপাত।","A bolt from the blue.");
        map.put("A bolt from the blue.","বিনা মেঘে বজ্রপাত।");
        map.put("ঘর-পোড়া গরু সিন্দুরে মেঘ দেখলে ভয় পায়।","A burnt child dreads the fire or Once bitten, twice shy.");
        map.put("A burnt child dreads the fire or Once bitten, twice shy.","ঘর-পোড়া গরু সিন্দুরে মেঘ দেখলে ভয় পায়।");
        map.put("সোজা আঙ্গুলে ঘি ওঠে না।","A cat in gloves catches no mice.");
        map.put("A cat in gloves catches no mice.","সোজা আঙ্গুলে ঘি ওঠে না।");
        map.put("যতক্ষণ শ্বাস, ততক্ষণ আঁশ।","A drawing man catches or clutches at a straw .");
        map.put("A drawing man catches or clutches at a straw .","যতক্ষণ শ্বাস, ততকক্ষণ আঁশ। ");
        map.put("অসময়ের বন্ধুই প্রকৃত বন্ধু।","A friend in need is a friend indeed.");
        map.put("A friend in need is a friend indeed.","অসময়ের বন্ধুই প্রকৃত বন্ধু।");
        map.put("ভাত ছড়ালে কাকের অভাব হয় না।","A full purse never lacks friends.");
        map.put("A full purse never lacks friends.","ভাত ছড়ালে কাকের অভাব হয় না।");
        map.put("টাকায় বাঘের দুধ মেলে।","A golden key can open any door.");
        map.put("A golden key can open any door.","টাকায় বাঘের দুধ মেলে।");
        map.put("স্বামী ভালো হলে স্ত্রীও ভালো হয়।","A good husband makes a good wife.");
        map.put("A good husband makes a good wife.","স্বামী ভালো হলে স্ত্রীও ভালো হয়।");
        map.put("ঠাকুর ঘরে কে, আমি তো কলা খাইনি।","A guilty mind is always suspicious.");
        map.put("A guilty mind is always suspicious.","ঠাকুর ঘরে কে, আমি তো কলা খাইনি।");
        map.put("একাই একশো।","A host in himself.");
        map.put("A host in himself.","একাই একশো।");
        map.put("অল্পবিদ্যা ভয়ংকরী।","A little learning is a dangerous thing.");
        map.put("A little learning is a dangerous thing.","অল্পবিদ্যা ভয়ংকরী।");
        map.put("পাগলে কী না বলে, ছাগলে কী না খায়।","A mad man and a animal have no difference.");
        map.put("A mad man and a animal have no difference.","পাগলে কী না বলে, ছাগলে কী না খায়।");
        map.put("কাঁচাতে না নোয়ালে বাঁশ, পাকলে করে ঠাসঠাস।","A pet lamb, makes a cross ram.");
        map.put("A pet lamb, makes a cross ram.","কাঁচাতে না নোয়ালে বাঁশ, পাকলে করে ঠাসঠাস।");
        map.put("যে রক্ষক সেই ভক্ষক।","A poacher turned gamekeeper .");
        map.put("A poacher turned gamekeeper .","যে রক্ষক সেই ভক্ষক।");
        map.put("গেঁয়ো যোগী ভিখ পায় না।","A prophet is not without honor save in his own country.");
        map.put("A prophet is not without honor save in his own country.","গেঁয়ো যোগী ভিখ পায় না।");
        map.put("চোরে শোনে না ধর্মের কাহিনী।","A rogue is deaf to all good .");
        map.put("A rogue is deaf to all good .","চোরে শোনে না ধর্মের কাহিনী।");
        map.put("অসৎ সঙ্গে সর্বনাশ।","A rotten sheep infects the flock.");
        map.put("A rotten sheep infects the flock.","অসৎ সঙ্গে সর্বনাশ।");
        map.put("মনে বিষ, মুখে মধু","A serpent under the flower.");
        map.put("A serpent under the flower.","মনে বিষ, মুখে মধু");
        map.put("লঘু পাপে গুরু দন্ড।","A severe punishment for a venial offence.");
        map.put("A severe punishment for a venial offence.","লঘু পাপে গুরু দন্ড।");
        map.put("সময়ের এক ফোঁড় অসময়ের দশ ফোঁড়।","A stitch in time saves nine.");
        map.put("A stitch in time saves nine.","সময়ের এক ফোঁড় অসময়ের দশ ফোঁড়।");
        map.put("লোভে পাপ পাপে মৃত্যু।","A varice begets sin, sin begets death.");
        map.put("A varice begets sin, sin begets death.","লোভে পাপ পাপে মৃত্যু।");
        map.put("হিতে বিপরীত।","Adversity often leads to prosperity.");
        map.put("Adversity often leads to prosperity.","হিতে বিপরীত।");
        map.put("মেঘ দেখে করিসনে ভয়,আড়ালে তার সূর্য হাসে।","After clouds comes fair weather.");
        map.put("After clouds comes fair weather.","মেঘ দেখে করিসনে ভয়,আড়ালে তার সূর্য হাসে।");
        map.put("চোর পালালে বুদ্ধি বাড়ে।","After death comes the doctor.");
        map.put("After death comes the doctor.","চোর পালালে বুদ্ধি বাড়ে।");
        map.put("পৈতে থাকলেই বামুন হয় না।","All are not saints that go to church.");
        map.put("All are not saints that go to church.","পৈতে থাকলেই বামুন হয় না।");
        map.put("অতি লোভে তাঁতি নষ্ট।","All covet, all lost.");
        map.put("All covet, all lost.","অতি লোভে তাঁতি নষ্ট।");
        map.put("নানা মুনির নানা মত।","All feet tread not in one shoe.");
        map.put("All feet tread not in one shoe.","নানা মুনির নানা মত।");
        map.put("চকচক করলেই সোনা হয় না।","All that glitters is not gold.");
        map.put("All that glitters is not gold.","চকচক করলেই সোনা হয় না।");
        map.put("সবুরে মেওয়া ফলে।","All things come to him who waits.");
        map.put("All things come to him who waits.","সবুরে মেওয়া ফলে।");
        map.put("সব ভাল যার শেষ ভাল তার।","All's well that ends well.");
        map.put("All's well that ends well.","সব ভাল যার শেষ ভাল তার।");
        map.put("অলস মস্তিষ্ক শয়তানের কারখানা।","An idle brain is the devil’s workshop.");
        map.put("An idle brain is the devil’s workshop.","অলস মস্তিষ্ক শয়তানের কারখানা।");
        map.put("যেমন কর্ম তেমন ফল।","As you sow so you reap.");
        map.put("As you sow so you reap.","যেমন কর্ম তেমন ফল।");
        map.put("দুষ্ট গরুর চেয়ে শূন্য গোয়াল ভালো।","Better an empty house than an ill tenant.");
        map.put("Better an empty house than an ill tenant.","দুষ্ট গরুর চেয়ে শূন্য গোয়াল ভালো।");
        map.put("চোরে চোরে মাসতুতো ভাই।","Birds of a feather flock together.");
        map.put("Birds of a feather flock together.","চোরে চোরে মাসতুতো ভাই।");
        map.put("কয়লা ধুলে ময়লা যায় না।","Black will take no other hue.");
        map.put("Black will take no other hue.","কয়লা ধুলে ময়লা যায় না।");
        map.put("দুধ কলা দিয়ে সাপ পোষা।","Breed up a crow, and it will pluck your eyes.");
        map.put("Breed up a crow, and it will pluck your eyes.","দুধ কলা দিয়ে সাপ পোষা।");
        map.put("Black sheep","কুলাঙ্গার");
        map.put("Fair weather friend","সুসময়ের বন্ধু");
        map.put("A few","কিছু");
        map.put("Fish out of water","অস্বস্তিকর অবস্থা");
        map.put("Hard nut to crack","কঠোর প্ররিশ্রমের সাথে");
        map.put("jack of all trades","সবজান্তা কিন্তু ওস্তাদ নয়");
        map.put("lame excuse","অজুহাত");
        map.put("A lot of","প্রচুর");
        map.put("A man of letters","পন্ডিত ব্যক্তি");
        map.put("A man of word","এককথার মানুষ");
        map.put("A rainy day","দুর্দিন");
        map.put("A white elephant","গরীবের হাতি পোষার মত ব্যয়সাধ্য");
        map.put("Above all","সর্বোপরি");
        map.put("All in all","সর্বেসর্বা");
        map.put("All of a sudden","হঠাৎ");
        
        java.awt.EventQueue.invokeLater(() -> {
            new Dict().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AboutButton;
    private javax.swing.JLabel Appname;
    private javax.swing.JTextField BanField;
    private javax.swing.JButton BantoEngButton;
    private javax.swing.JTextField BantoEngResult;
    private javax.swing.JButton ClearBanButton;
    private javax.swing.JButton ClearEngButton;
    private javax.swing.JLabel Contact;
    private javax.swing.JLabel Developed;
    private javax.swing.JLabel Developer;
    private javax.swing.JLabel Email;
    private javax.swing.JTextField EngField;
    private javax.swing.JButton EngtoBanButton;
    private javax.swing.JTextField EngtoBanResult;
    private javax.swing.JLabel Info;
    private javax.swing.JLabel Institute;
    private javax.swing.JLabel Logo;
    private javax.swing.JLabel ResultBanLabel;
    private javax.swing.JLabel ResultEngLabel;
    private javax.swing.JLabel Version;
    private javax.swing.JPanel WordBook;
    private javax.swing.JLabel WriteBanLabel;
    private javax.swing.JLabel WriteEngLabel;
    // End of variables declaration//GEN-END:variables


}